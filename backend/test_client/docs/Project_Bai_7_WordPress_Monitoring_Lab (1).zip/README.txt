WORDPRESS MONITORING LAB - BAI 7
Prometheus + Grafana + Node Exporter + cAdvisor + MySQL Exporter + Blackbox Exporter

Mục tiêu:
- Hiểu Monitoring, Metrics, Pull/Push.
- Triển khai hệ thống bằng Docker Compose.
- Tách app-network và monitoring.
- Thu thập metrics host, container, MySQL và kiểm tra HTTP WordPress.
- Xây dựng dashboard Grafana và phân tích dữ liệu.

Các cổng:
8080 WordPress
9090 Prometheus
3000 Grafana
8081 cAdvisor
9100 Node Exporter
9104 MySQL Exporter
9115 Blackbox Exporter

Lệnh nhanh:
docker compose config
docker compose up -d
docker compose ps
docker compose logs -f prometheus
docker compose down
docker compose down -v

Truy cập:
http://localhost:8080
http://localhost:9090
http://localhost:3000  (admin/admin lần đầu)

Lưu ý:
Không expose MySQL port 3306 ra host. mysql-exporter là service duy nhất nối đồng thời
app-network và monitoring để lấy metrics MySQL rồi cung cấp cho Prometheus.
